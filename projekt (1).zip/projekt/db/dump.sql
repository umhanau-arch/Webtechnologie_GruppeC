-- ============================================
-- Bowl Konfigurator - SQL Dump
-- ============================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- Datenbank erstellen
CREATE DATABASE IF NOT EXISTS `bowl_konfigurator` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `bowl_konfigurator`;

-- ============================================
-- Tabelle: users
-- ============================================
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `address` VARCHAR(200) DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `zip` VARCHAR(10) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Tabelle: categories (Konfigurations-Schritte)
-- ============================================
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `step_number` INT NOT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  `max_select` INT DEFAULT 1,
  `icon` VARCHAR(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `categories` (`name`, `step_number`, `description`, `max_select`, `icon`) VALUES
('Basis', 1, 'Wähle deine Bowl-Basis', 1, '🍚'),
('Protein', 2, 'Wähle dein Protein (max. 2)', 2, '🥩'),
('Gemüse & Extras', 2, 'Wähle dein Gemüse und Extras (max. 6)', 6, '🥦'),
('Sauce', 3, 'Wähle deine Sauce (max. 2)', 2, '🫙'),
('Topping', 3, 'Wähle deine Toppings (max. 3)', 3, '✨');

-- ============================================
-- Tabelle: ingredients (Zutaten)
-- ============================================
CREATE TABLE `ingredients` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `price` DECIMAL(5,2) NOT NULL,
  `calories` INT DEFAULT 0,
  `protein` DECIMAL(5,1) DEFAULT 0,
  `is_vegan` TINYINT(1) DEFAULT 0,
  `is_vegetarian` TINYINT(1) DEFAULT 0,
  `is_glutenfree` TINYINT(1) DEFAULT 0,
  `image` VARCHAR(100) DEFAULT NULL,
  `available` TINYINT(1) DEFAULT 1,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Basis (Schritt 1)
INSERT INTO `ingredients` (`category_id`, `name`, `price`, `calories`, `protein`, `is_vegan`, `is_vegetarian`, `is_glutenfree`, `image`) VALUES
(1, 'Jasminreis', 2.50, 180, 3.5, 1, 1, 1, 'reis.jpg'),
(1, 'Quinoa', 3.00, 160, 6.0, 1, 1, 1, 'quinoa.jpg'),
(1, 'Vollkornnudeln', 2.50, 200, 7.0, 1, 1, 0, 'nudeln.jpg'),
(1, 'Gemischter Salat', 2.00, 40, 2.0, 1, 1, 1, 'salat.jpg'),
(1, 'Süßkartoffel', 2.80, 130, 2.5, 1, 1, 1, 'suesskartoffel.jpg');

-- Protein (Schritt 2)
INSERT INTO `ingredients` (`category_id`, `name`, `price`, `calories`, `protein`, `is_vegan`, `is_vegetarian`, `is_glutenfree`, `image`) VALUES
(2, 'Gegrilltes Hähnchen', 3.50, 165, 31.0, 0, 0, 1, 'haehnchen.jpg'),
(2, 'Lachs', 4.50, 208, 28.0, 0, 0, 1, 'lachs.jpg'),
(2, 'Garnelen', 4.00, 99, 24.0, 0, 0, 1, 'garnelen.jpg'),
(2, 'Tofu', 2.50, 144, 15.0, 1, 1, 1, 'tofu.jpg'),
(2, 'Falafel', 2.80, 333, 13.0, 1, 1, 0, 'falafel.jpg'),
(2, 'Thunfisch', 3.00, 132, 28.0, 0, 0, 1, 'thunfisch.jpg'),
(2, 'Rindfleisch', 4.00, 250, 26.0, 0, 0, 1, 'rind.jpg');

-- Gemüse & Extras (Schritt 2 - hier kommen die 20+ Optionen!)
INSERT INTO `ingredients` (`category_id`, `name`, `price`, `calories`, `protein`, `is_vegan`, `is_vegetarian`, `is_glutenfree`, `image`) VALUES
(3, 'Avocado', 1.50, 160, 2.0, 1, 1, 1, 'avocado.jpg'),
(3, 'Mais', 0.50, 86, 3.2, 1, 1, 1, 'mais.jpg'),
(3, 'Rote Paprika', 0.50, 31, 1.0, 1, 1, 1, 'paprika.jpg'),
(3, 'Gurke', 0.50, 16, 0.7, 1, 1, 1, 'gurke.jpg'),
(3, 'Edamame', 1.00, 121, 11.0, 1, 1, 1, 'edamame.jpg'),
(3, 'Mango', 1.00, 60, 0.8, 1, 1, 1, 'mango.jpg'),
(3, 'Rote Zwiebeln', 0.30, 40, 1.1, 1, 1, 1, 'zwiebeln.jpg'),
(3, 'Cherry-Tomaten', 0.50, 18, 0.9, 1, 1, 1, 'tomaten.jpg'),
(3, 'Spinat', 0.50, 23, 2.9, 1, 1, 1, 'spinat.jpg'),
(3, 'Brokkoli', 0.50, 34, 2.8, 1, 1, 1, 'brokkoli.jpg'),
(3, 'Karotten', 0.30, 41, 0.9, 1, 1, 1, 'karotten.jpg'),
(3, 'Rote Beete', 0.80, 43, 1.6, 1, 1, 1, 'rotebeete.jpg'),
(3, 'Zucchini', 0.50, 17, 1.2, 1, 1, 1, 'zucchini.jpg'),
(3, 'Kichererbsen', 0.80, 164, 8.9, 1, 1, 1, 'kichererbsen.jpg'),
(3, 'Oliven', 0.80, 115, 0.8, 1, 1, 1, 'oliven.jpg'),
(3, 'Jalapeños', 0.50, 29, 0.9, 1, 1, 1, 'jalapenos.jpg'),
(3, 'Rucola', 0.50, 25, 2.6, 1, 1, 1, 'rucola.jpg'),
(3, 'Süßkartoffel-Würfel', 1.00, 86, 1.6, 1, 1, 1, 'suesskartoffelwuerfel.jpg'),
(3, 'Pilze', 0.80, 22, 3.1, 1, 1, 1, 'pilze.jpg'),
(3, 'Feta-Käse', 1.00, 264, 14.2, 0, 1, 1, 'feta.jpg'),
(3, 'Mozzarella', 1.00, 280, 18.0, 0, 1, 1, 'mozzarella.jpg'),
(3, 'Schwarze Bohnen', 0.80, 132, 8.9, 1, 1, 1, 'bohnen.jpg');

-- Saucen (Schritt 3)
INSERT INTO `ingredients` (`category_id`, `name`, `price`, `calories`, `protein`, `is_vegan`, `is_vegetarian`, `is_glutenfree`, `image`) VALUES
(4, 'Teriyaki', 0.80, 60, 1.2, 1, 1, 0, 'teriyaki.jpg'),
(4, 'Tahini', 0.80, 90, 2.6, 1, 1, 1, 'tahini.jpg'),
(4, 'Sriracha-Mayo', 0.80, 100, 0.5, 0, 1, 1, 'sriracha.jpg'),
(4, 'Honig-Senf', 0.80, 70, 0.8, 0, 1, 1, 'honigsenf.jpg'),
(4, 'Pesto', 0.80, 120, 3.0, 0, 1, 0, 'pesto.jpg'),
(4, 'Mango-Chili', 0.80, 55, 0.5, 1, 1, 1, 'mangochili.jpg'),
(4, 'Griechischer Joghurt', 0.80, 59, 3.5, 0, 1, 1, 'joghurt.jpg'),
(4, 'Zitrone-Kräuter', 0.80, 40, 0.3, 1, 1, 1, 'zitronen.jpg');

-- Toppings (Schritt 3)
INSERT INTO `ingredients` (`category_id`, `name`, `price`, `calories`, `protein`, `is_vegan`, `is_vegetarian`, `is_glutenfree`, `image`) VALUES
(5, 'Sesam', 0.30, 52, 1.6, 1, 1, 1, 'sesam.jpg'),
(5, 'Geröstete Nüsse', 0.50, 85, 2.0, 1, 1, 1, 'nuesse.jpg'),
(5, 'Croutons', 0.50, 65, 1.5, 1, 1, 0, 'croutons.jpg'),
(5, 'Granatapfelkerne', 0.80, 35, 0.5, 1, 1, 1, 'granatapfel.jpg'),
(5, 'Kürbiskerne', 0.50, 70, 3.0, 1, 1, 1, 'kuerbis.jpg'),
(5, 'Frischer Koriander', 0.30, 5, 0.3, 1, 1, 1, 'koriander.jpg'),
(5, 'Schnittlauch', 0.30, 4, 0.3, 1, 1, 1, 'schnittlauch.jpg'),
(5, 'Chiliflocken', 0.30, 15, 0.5, 1, 1, 1, 'chili.jpg');

-- ============================================
-- Tabelle: preset_bowls (Vorkonfigurierte Bowls)
-- ============================================
CREATE TABLE `preset_bowls` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  `tag` VARCHAR(50) DEFAULT NULL,
  `color` VARCHAR(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `preset_bowls` (`name`, `description`, `tag`, `color`) VALUES
('Asia Bowl', 'Jasminreis, Hähnchen, Edamame, Mango, Teriyaki, Sesam', 'Beliebt', '#FF6B35'),
('Mediterranean Bowl', 'Quinoa, Falafel, Feta, Oliven, Tahini, Granatapfelkerne', 'Vegetarisch', '#4CAF50'),
('Power Bowl', 'Quinoa, Lachs, Avocado, Spinat, Zitrone-Kräuter, Kürbiskerne', 'High Protein', '#2196F3'),
('Vegan Dream', 'Süßkartoffel, Tofu, Kichererbsen, Rote Beete, Mango-Chili, Nüsse', 'Vegan', '#9C27B0');

-- ============================================
-- Tabelle: preset_items
-- ============================================
CREATE TABLE `preset_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `preset_id` INT NOT NULL,
  `ingredient_id` INT NOT NULL,
  FOREIGN KEY (`preset_id`) REFERENCES `preset_bowls`(`id`),
  FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Asia Bowl (preset 1): Jasminreis(1), Hähnchen(6), Edamame(15), Mango(16), Teriyaki(29), Sesam(37)
INSERT INTO `preset_items` (`preset_id`, `ingredient_id`) VALUES (1,1),(1,6),(1,15),(1,16),(1,29),(1,37);
-- Mediterranean Bowl (preset 2): Quinoa(2), Falafel(11), Feta(30), Oliven(25), Tahini(30), Granatapfel(40)
INSERT INTO `preset_items` (`preset_id`, `ingredient_id`) VALUES (2,2),(2,11),(2,30),(2,25),(2,30),(2,40);
-- Power Bowl (preset 3): Quinoa(2), Lachs(7), Avocado(13), Spinat(19), Zitrone(36), Kürbiskerne(41)
INSERT INTO `preset_items` (`preset_id`, `ingredient_id`) VALUES (3,2),(3,7),(3,13),(3,19),(3,36),(3,41);
-- Vegan Dream (preset 4): Süßkartoffel(5), Tofu(10), Kichererbsen(24), RoteBeete(22), MangoChili(34), Nüsse(38)
INSERT INTO `preset_items` (`preset_id`, `ingredient_id`) VALUES (4,5),(4,10),(4,24),(4,22),(4,34),(4,38);

-- ============================================
-- Tabelle: configurations (Gespeicherte Konfigurationen)
-- ============================================
CREATE TABLE `configurations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL DEFAULT 'Meine Bowl',
  `total_price` DECIMAL(6,2) NOT NULL,
  `total_calories` INT DEFAULT 0,
  `total_protein` DECIMAL(5,1) DEFAULT 0,
  `coupon_code` VARCHAR(50) DEFAULT NULL,
  `discount` DECIMAL(5,2) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Tabelle: config_items
-- ============================================
CREATE TABLE `config_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `config_id` INT NOT NULL,
  `ingredient_id` INT NOT NULL,
  FOREIGN KEY (`config_id`) REFERENCES `configurations`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Tabelle: coupons (Gutscheincodes)
-- ============================================
CREATE TABLE `coupons` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `discount_percent` INT NOT NULL,
  `valid_until` DATE DEFAULT NULL,
  `active` TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `coupons` (`code`, `discount_percent`, `valid_until`, `active`) VALUES
('BOWL10', 10, '2026-12-31', 1),
('WELCOME20', 20, '2026-06-30', 1),
('VEGAN15', 15, '2026-12-31', 1);
