-- Diese Tabelle zur bestehenden Datenbank hinzufügen
-- In MySQL Shell eingeben: SOURCE C:/xampp/htdocs/projekt/db/bestellungen.sql;

USE bowl_konfigurator;

CREATE TABLE IF NOT EXISTS `bestellungen` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `config_id` INT DEFAULT NULL,
  `liefer_name` VARCHAR(100) NOT NULL,
  `liefer_adresse` VARCHAR(200) NOT NULL,
  `liefer_plz` VARCHAR(10) NOT NULL,
  `liefer_stadt` VARCHAR(100) NOT NULL,
  `liefer_zeit` VARCHAR(100) NOT NULL,
  `zahlungsart` VARCHAR(50) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'ausstehend',
  `erstellt_am` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
