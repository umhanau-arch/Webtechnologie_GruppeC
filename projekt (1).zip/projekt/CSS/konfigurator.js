// js/konfigurator.js
// Haupt-JavaScript für den Bowl-Konfigurator

// ============================================
// Globaler State: Welche Zutaten sind gewählt
// ============================================
const selected = {};   // { ingredientId: { id, name, price, cal, protein, step, cat, max } }
let currentStep = 1;
let appliedCoupon = null;

// ============================================
// Schritt-Navigation
// ============================================
function goToStep(stepNum) {
    // Validierung Schritt 1: Basis muss gewählt sein
    if (stepNum > 1 && !hasSelectionInStep(1)) {
        alert('Bitte wähle zuerst eine Basis für deine Bowl!');
        return;
    }

    // Alle Schritte ausblenden
    document.querySelectorAll('.config-step').forEach(el => el.classList.add('d-none'));

    // Zielschritt anzeigen
    const target = document.getElementById('step-' + stepNum);
    if (target) {
        target.classList.remove('d-none');
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    currentStep = stepNum;
    updateProgressBar(stepNum);

    // Bei Schritt 4: Zusammenfassung aktualisieren
    if (stepNum === 4) {
        renderSummary();
    }
}

// Prüft ob in einem Schritt mindestens eine Zutat gewählt ist
function hasSelectionInStep(step) {
    return Object.values(selected).some(ing => ing.step == step);
}

// Progress Bar aktualisieren
function updateProgressBar(step) {
    for (let i = 1; i <= 4; i++) {
        const prog = document.getElementById('prog-' + i);
        const line = document.getElementById('line-' + i);
        if (!prog) continue;

        prog.classList.remove('active', 'completed');
        if (i < step) prog.classList.add('completed');
        else if (i === step) prog.classList.add('active');

        if (line) {
            line.classList.remove('active');
            if (i < step) line.classList.add('active');
        }
    }
}

// ============================================
// Zutat auswählen / abwählen
// ============================================
function toggleIngredient(card) {
    const id      = card.dataset.id;
    const name    = card.dataset.name;
    const price   = parseFloat(card.dataset.price);
    const cal     = parseInt(card.dataset.cal);
    const protein = parseFloat(card.dataset.protein);
    const step    = parseInt(card.dataset.step);
    const cat     = card.dataset.cat || 'default';
    const max     = parseInt(card.dataset.max);

    if (selected[id]) {
        // Abwählen
        delete selected[id];
        card.classList.remove('selected');
    } else {
        // Wählen – prüfe Limit pro Kategorie (wenn step 1: nur 1 erlaubt)
        const countInCat = Object.values(selected).filter(i => i.step === step && i.cat === cat).length;

        if (max === 1 && step === 1) {
            // Radio-Verhalten: alle anderen in Schritt 1 abwählen
            Object.keys(selected).forEach(selId => {
                if (selected[selId].step === 1) {
                    delete selected[selId];
                    const otherCard = document.querySelector(`.ingredient-card[data-id="${selId}"]`);
                    if (otherCard) otherCard.classList.remove('selected');
                }
            });
        } else if (countInCat >= max) {
            showToast(`Maximal ${max} Auswahl(en) für "${cat}" erlaubt!`);
            return;
        }

        selected[id] = { id, name, price, cal, protein, step, cat, max };
        card.classList.add('selected');
    }

    updateLivePreview();
}

// ============================================
// Live-Vorschau rechts aktualisieren
// ============================================
function updateLivePreview() {
    const list       = document.getElementById('selected-list');
    const priceEl    = document.getElementById('live-price');
    const calEl      = document.getElementById('live-cal');
    const proteinEl  = document.getElementById('live-protein');
    const bowlVisual = document.getElementById('bowl-visual');

    const items = Object.values(selected);

    // Preis & Nährwerte berechnen
    let totalPrice   = 0;
    let totalCal     = 0;
    let totalProtein = 0;
    items.forEach(i => {
        totalPrice   += i.price;
        totalCal     += i.cal;
        totalProtein += i.protein;
    });

    // Preisanzeige
    priceEl.textContent   = formatPrice(totalPrice);
    calEl.textContent     = totalCal;
    proteinEl.textContent = totalProtein.toFixed(1);

    // Liste der gewählten Zutaten
    if (items.length === 0) {
        list.innerHTML = '<p class="text-muted text-center small">Wähle deine Zutaten</p>';
        bowlVisual.innerHTML = '<span class="bowl-empty-text">Noch leer...</span>';
    } else {
        list.innerHTML = items.map(i =>
            `<div class="selected-item">
                <span>${i.name}</span>
                <span class="selected-price">+${formatPrice(i.price)}</span>
            </div>`
        ).join('');

        // Bowl-Visual: Emojis anzeigen
        const emojis = items.map(i => getEmojiForName(i.name)).slice(0, 8);
        bowlVisual.innerHTML = emojis.map((e, idx) =>
            `<span class="bowl-ingredient-emoji" style="animation-delay:${idx * 0.1}s">${e}</span>`
        ).join('');
    }
}

// ============================================
// Filter-Funktionen
// ============================================
function filterIngredients(step, filterType) {
    const stepEl = document.getElementById('step-' + step);
    if (!stepEl) return;

    const cards = stepEl.querySelectorAll('.ingredient-card');
    cards.forEach(card => {
        let show = true;
        if (filterType === 'vegan') show = card.classList.contains('is-vegan');
        else if (filterType === 'vegetarian') show = card.classList.contains('is-vegetarian');
        else if (filterType === 'glutenfree') show = card.classList.contains('is-glutenfree');
        card.style.display = show ? '' : 'none';
    });

    // Aktiven Filter-Button markieren
    const filterBtns = stepEl.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

// ============================================
// Suchfunktion (Schritt 2)
// ============================================
function searchIngredients(step) {
    const query = document.getElementById('search-step' + step).value.toLowerCase();
    const stepEl = document.getElementById('step-' + step);
    const cards = stepEl.querySelectorAll('.ingredient-card');

    cards.forEach(card => {
        const name = card.querySelector('.ingredient-name').textContent.toLowerCase();
        card.style.display = name.includes(query) ? '' : 'none';
    });
}

// ============================================
// Zusammenfassung rendern (Schritt 4)
// ============================================
function renderSummary() {
    const container = document.getElementById('summary-content');
    const items = Object.values(selected);

    // Nach Schritten gruppieren
    const byStep = { 1: [], 2: [], 3: [] };
    items.forEach(i => byStep[i.step].push(i));

    const stepNames = { 1: '🍚 Basis', 2: '🥩 Protein & Gemüse', 3: '🫙 Sauce & Toppings' };

    let html = '';
    [1, 2, 3].forEach(step => {
        if (byStep[step].length > 0) {
            html += `<div class="summary-group">
                <h6 class="summary-group-title">${stepNames[step]}</h6>
                ${byStep[step].map(i => `
                    <div class="summary-item">
                        <span>${getEmojiForName(i.name)} ${i.name}</span>
                        <span>+${formatPrice(i.price)}</span>
                    </div>`).join('')}
            </div>`;
        }
    });

    container.innerHTML = html || '<p class="text-muted">Keine Zutaten gewählt.</p>';
    updatePriceSummary();
}

function updatePriceSummary() {
    const items = Object.values(selected);
    let subtotal = items.reduce((sum, i) => sum + i.price, 0);
    let totalCal = items.reduce((sum, i) => sum + i.cal, 0);
    let totalPro = items.reduce((sum, i) => sum + i.protein, 0);

    document.getElementById('price-subtotal').textContent = formatPrice(subtotal);
    document.getElementById('nut-cal').textContent = totalCal;
    document.getElementById('nut-protein').textContent = totalPro.toFixed(1) + 'g';

    let discount = 0;
    if (appliedCoupon) {
        discount = subtotal * appliedCoupon.percent / 100;
        document.getElementById('discount-row').classList.remove('d-none');
        document.getElementById('discount-label').textContent = `Rabatt (${appliedCoupon.code} -${appliedCoupon.percent}%)`;
        document.getElementById('price-discount').textContent = '-' + formatPrice(discount);
    }

    document.getElementById('price-total').textContent = formatPrice(subtotal - discount);
}

// ============================================
// Gutscheincode einlösen
// ============================================
function applyCoupon() {
    const code = document.getElementById('coupon-input').value.trim().toUpperCase();
    const msgEl = document.getElementById('coupon-msg');

    if (!code) return;

    fetch('api/check_coupon.php?code=' + encodeURIComponent(code))
        .then(r => r.json())
        .then(data => {
            if (data.valid) {
                appliedCoupon = { code: data.code, percent: data.discount_percent };
                msgEl.innerHTML = `<span class="text-success">✓ Gutschein "${data.code}" eingelöst! ${data.discount_percent}% Rabatt.</span>`;
                updatePriceSummary();
            } else {
                msgEl.innerHTML = `<span class="text-danger">✗ Ungültiger oder abgelaufener Gutscheincode.</span>`;
                appliedCoupon = null;
                updatePriceSummary();
            }
        })
        .catch(() => {
            msgEl.innerHTML = `<span class="text-danger">Fehler beim Prüfen des Codes.</span>`;
        });
}

// ============================================
// Konfiguration speichern
// ============================================
function saveConfig() {
    const items = Object.values(selected);
    if (items.length === 0) {
        showToast('Bitte wähle zuerst Zutaten aus!');
        return;
    }

    const bowlName = document.getElementById('bowl-name').value.trim() || 'Meine Bowl';
    const totalPrice = items.reduce((sum, i) => sum + i.price, 0);
    const totalCal   = items.reduce((sum, i) => sum + i.cal, 0);
    const totalPro   = items.reduce((sum, i) => sum + i.protein, 0);
    const discount   = appliedCoupon ? totalPrice * appliedCoupon.percent / 100 : 0;

    const payload = {
        name: bowlName,
        total_price: (totalPrice - discount).toFixed(2),
        total_calories: totalCal,
        total_protein: totalPro.toFixed(1),
        coupon_code: appliedCoupon ? appliedCoupon.code : null,
        discount: discount.toFixed(2),
        ingredient_ids: items.map(i => i.id)
    };

    fetch('api/save_config.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(r => r.json())
    .then(data => {
        const msgEl = document.getElementById('save-msg');
        if (data.success) {
            msgEl.innerHTML = '<div class="alert alert-success">✓ Bowl wurde gespeichert! <a href="meine-bowls.php">Meine Bowls ansehen →</a></div>';
        } else {
            msgEl.innerHTML = `<div class="alert alert-danger">${data.error || 'Fehler beim Speichern.'}</div>`;
        }
    });
}

// ============================================
// Bestellen
// ============================================
function orderNow() {
    const items = Object.values(selected);
    if (items.length === 0) {
        showToast('Deine Bowl ist noch leer!');
        return;
    }
    const modal = new bootstrap.Modal(document.getElementById('orderModal'));
    modal.show();
}

// ============================================
// Hilfsfunktionen
// ============================================
function formatPrice(num) {
    return num.toFixed(2).replace('.', ',') + ' €';
}

function showToast(msg) {
    // Einfaches Toast-Feedback
    const toast = document.createElement('div');
    toast.className = 'custom-toast';
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 300); }, 2500);
}

function getEmojiForName(name) {
    const map = {
        'Jasminreis':'🍚','Quinoa':'🌾','Vollkornnudeln':'🍝','Gemischter Salat':'🥗','Süßkartoffel':'🍠',
        'Gegrilltes Hähnchen':'🍗','Lachs':'🐟','Garnelen':'🦐','Tofu':'🟨','Falafel':'🟤',
        'Thunfisch':'🐠','Rindfleisch':'🥩',
        'Avocado':'🥑','Mais':'🌽','Rote Paprika':'🫑','Gurke':'🥒','Edamame':'🫘',
        'Mango':'🥭','Rote Zwiebeln':'🧅','Cherry-Tomaten':'🍅','Spinat':'🥬',
        'Brokkoli':'🥦','Karotten':'🥕','Rote Beete':'🔴','Zucchini':'🟩',
        'Kichererbsen':'🫘','Oliven':'🫒','Jalapeños':'🌶️','Rucola':'🥬',
        'Süßkartoffel-Würfel':'🍠','Pilze':'🍄','Feta-Käse':'🧀','Mozzarella':'🧀',
        'Schwarze Bohnen':'🫘',
        'Teriyaki':'🫙','Tahini':'🫙','Sriracha-Mayo':'🌶️','Honig-Senf':'🍯',
        'Pesto':'🌿','Mango-Chili':'🥭','Griechischer Joghurt':'🥛','Zitrone-Kräuter':'🍋',
        'Sesam':'⚪','Geröstete Nüsse':'🥜','Croutons':'🍞','Granatapfelkerne':'💎',
        'Kürbiskerne':'🌰','Frischer Koriander':'🌿','Schnittlauch':'🌿','Chiliflocken':'🌶️',
    };
    return map[name] || '🥗';
}

// ============================================
// Preset laden (wenn URL-Parameter vorhanden)
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    // Vorkonfigurierte Bowl aktivieren
    if (typeof PRESET_IDS !== 'undefined' && PRESET_IDS.length > 0) {
        PRESET_IDS.forEach(id => {
            const card = document.querySelector(`.ingredient-card[data-id="${id}"]`);
            if (card) toggleIngredient(card);
        });
    }
});
