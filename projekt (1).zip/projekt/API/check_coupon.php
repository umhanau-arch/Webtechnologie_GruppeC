<?php
// api/check_coupon.php
require_once '../includes/db.php';

header('Content-Type: application/json');

$code = strtoupper(trim($_GET['code'] ?? ''));

if (empty($code)) {
    echo json_encode(['valid' => false]);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM coupons WHERE code =? AND active = 1 AND (valid_until IS NULL OR valid_until >= CURDATE())");
$stmt->execute([$code]);
$coupon = $stmt->fetch();

if ($coupon) {
    echo json_encode(['valid' => true, 'code' => $coupon['code'], 'discount_percent' => $coupon['discount_percent']]);
} else {
    echo json_encode(['valid' => false]);
}
