<?php
// api/save_config.php
require_once '../includes/auth.php';
require_once '../includes/db.php';

header('Content-Type: application/json');

// Nur eingeloggte User dürfen speichern
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'error' => 'Nicht eingeloggt.']);
    exit;
}

// JSON-Body lesen
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || empty($data['ingredient_ids'])) {
    echo json_encode(['success' => false, 'error' => 'Ungültige Daten.']);
    exit;
}

$userId      = $_SESSION['user_id'];
$name        = substr(trim($data['name'] ?? 'Meine Bowl'), 0, 100);
$totalPrice  = (float)($data['total_price'] ?? 0);
$totalCal    = (int)($data['total_calories'] ?? 0);
$totalPro    = (float)($data['total_protein'] ?? 0);
$couponCode  = $data['coupon_code'] ?? null;
$discount    = (float)($data['discount'] ?? 0);
$ingredients = $data['ingredient_ids'];

try {
    $pdo->beginTransaction();

    // Konfiguration speichern
    $stmt = $pdo->prepare('INSERT INTO configurations (user_id, name, total_price, total_calories, total_protein, coupon_code, discount) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$userId, $name, $totalPrice, $totalCal, $totalPro, $couponCode, $discount]);
    $configId = $pdo->lastInsertId();

    // Zutaten speichern
    $stmt = $pdo->prepare('INSERT INTO config_items (config_id, ingredient_id) VALUES (?, ?)');
    foreach ($ingredients as $ingId) {
        $stmt->execute([$configId, (int)$ingId]);
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'config_id' => $configId]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'error' => 'Datenbankfehler.']);
}
