<?php
// includes/auth.php
// Session starten und Login-Check

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Prüft ob der User eingeloggt ist.
 * Wenn nicht → Weiterleitung zur Login-Seite.
 */
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Gibt zurück ob der User eingeloggt ist (true/false).
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Gibt den aktuellen User-Namen zurück (oder leer).
 */
function getUsername() {
    return $_SESSION['user_name'] ?? '';
}
